import uuid
from decimal import Decimal
from datetime import datetime, timezone, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Response, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.core.dependencies import get_current_user, require_roles, check_license
from app.core.audit import log_action
from app.core.file_storage import save_fee_proof_file, resolve_fee_proof_path
from app.core.notifications import notify
from app.models import FeeVoucher, FeeProof, User, ParentStudentLink, FeeStructure, Subject, Batch, Enrollment
from app.schemas.fees import (
    FeeVoucherCreate, FeeVoucherOut, FeeProofReview, FeeProofOut,
    FeeStructureCreate, FeeStructureOut, FeeStructureAmountUpdate,
)

router = APIRouter(prefix="/api/fees", tags=["fees"], dependencies=[Depends(check_license)])


def _latest_proof_for(db: Session, voucher_id: uuid.UUID) -> Optional[FeeProof]:
    """No status column on fee_vouchers: derived from the latest non-deleted fee_proofs row.
    Single-voucher lookup — used by the single-object endpoints below
    (create_voucher, generate_fee_bill, download_fee_bill_pdf,
    list_proofs_for_voucher/download_fee_proof_file's voucher check). For
    a *list* of vouchers, use _latest_proofs_by_voucher instead — calling
    this once per row there was an N+1 query (one extra round-trip per
    voucher on every GET /vouchers)."""
    return db.query(FeeProof).filter(
        FeeProof.voucher_id == voucher_id, FeeProof.deleted_at.is_(None)
    ).order_by(FeeProof.uploaded_at.desc()).first()


def _latest_proofs_by_voucher(db: Session, voucher_ids: List[uuid.UUID]) -> dict:
    """Batch version of _latest_proof_for for GET /vouchers: one query for
    every voucher_id in the page instead of one query per voucher. Fetches
    every non-deleted proof for the given vouchers ordered newest-first,
    then keeps only the first (= latest) one seen per voucher_id — same
    'latest wins' semantics as the single-voucher version's .order_by(...).first().
    """
    if not voucher_ids:
        return {}
    rows = (
        db.query(FeeProof)
        .filter(FeeProof.voucher_id.in_(voucher_ids), FeeProof.deleted_at.is_(None))
        .order_by(FeeProof.voucher_id, FeeProof.uploaded_at.desc())
        .all()
    )
    latest_by_voucher: dict = {}
    for proof in rows:
        latest_by_voucher.setdefault(proof.voucher_id, proof)
    return latest_by_voucher


def _status_text_for(latest_proof: Optional[FeeProof]) -> str:
    """Lowercase to match the frontend's DerivedVoucherStatus literal union."""
    if not latest_proof:
        return "pending"
    if latest_proof.status == "pending":
        return "submitted"
    if latest_proof.status == "approved":
        return "paid"
    return "rejected"


def _voucher_number(voucher: FeeVoucher) -> str:
    """Display-only invoice/voucher code — see FeeVoucherOut.voucher_number
    for why this isn't a stored column. Format: INV-<year>-<8 hex chars>."""
    return f"INV-{voucher.generated_at.year}-{voucher.id.hex[:8].upper()}"


_UNSET = object()  # sentinel distinct from a real "no proof exists yet" None


def _voucher_out(db: Session, voucher: FeeVoucher, student_name: str,
                  latest_proof: Optional[FeeProof] = _UNSET) -> FeeVoucherOut:
    """`latest_proof`: pass it in (even None, meaning 'confirmed no proof')
    when the caller already resolved it via a batch query, to skip the
    per-row lookup below. The sentinel default _UNSET (not None — None is
    itself a valid, meaningful value here) means 'not supplied, look it up
    the single-voucher way' — preserves the original behavior for every
    other call site (create_voucher, generate_fee_bill) that only ever
    builds one voucher at a time and has nothing to batch against."""
    if latest_proof is _UNSET:
        latest_proof = _latest_proof_for(db, voucher.id)
    return FeeVoucherOut(
        **{k: v for k, v in voucher.__dict__.items() if not k.startswith("_")},
        student_full_name=student_name,
        status=_status_text_for(latest_proof),
        latest_proof_id=latest_proof.id if latest_proof else None,
        voucher_number=_voucher_number(voucher),
    )


def _can_access_student_fees(current_user: User, student_id: uuid.UUID, db: Session) -> bool:
    if current_user.role in ("admin", "coordinator"):
        return True
    if current_user.role == "student":
        return current_user.id == student_id
    if current_user.role == "parent":
        link = db.query(ParentStudentLink).filter(
            ParentStudentLink.parent_id == current_user.id,
            ParentStudentLink.student_id == student_id,
            ParentStudentLink.deleted_at.is_(None),
        ).first()
        return link is not None
    return False


@router.post("/vouchers", response_model=FeeVoucherOut, status_code=status.HTTP_201_CREATED)
def create_voucher(payload: FeeVoucherCreate, db: Session = Depends(get_db),
                    current_user: User = Depends(require_roles("admin", "coordinator"))):
    """Normally auto-generated by a scheduled job; exposed here for manual/admin generation too."""
    voucher = FeeVoucher(**payload.model_dump())
    db.add(voucher)
    db.commit()
    db.refresh(voucher)
    student = db.query(User).filter(User.id == voucher.student_id).first()
    return _voucher_out(db, voucher, student.full_name if student else "Unknown")


@router.get("/vouchers", response_model=List[FeeVoucherOut])
def list_vouchers(student_id: Optional[uuid.UUID] = None,
                   months: Optional[int] = None,
                   db: Session = Depends(get_db),
                   current_user: User = Depends(get_current_user)):
    """
    Admin/Coordinator with no student_id get every voucher (this is what
    the Pending Proofs review screen calls, filtering to 'submitted'
    client-side since there's no server-side status column to filter on).
    Student/Parent are always scoped to their own/linked student(s)
    regardless of the student_id param.

    `months` — Admin Sub-Sprint 4's "historical records with 3-month filter
    drop-down." Optional and open-ended (any integer, not hardcoded to 3)
    so the same param covers "last month" or "last 6 months" too; the
    frontend's dropdown just happens to default to 3.
    """
    query = db.query(FeeVoucher).filter(FeeVoucher.deleted_at.is_(None))
    if current_user.role == "student":
        query = query.filter(FeeVoucher.student_id == current_user.id)
    elif current_user.role == "parent":
        linked_ids = [row.student_id for row in db.query(ParentStudentLink.student_id).filter(
            ParentStudentLink.parent_id == current_user.id, ParentStudentLink.deleted_at.is_(None)
        ).all()]
        query = query.filter(FeeVoucher.student_id.in_(linked_ids or [uuid.uuid4()]))
    elif student_id:
        query = query.filter(FeeVoucher.student_id == student_id)

    if months:
        cutoff = datetime.now(timezone.utc) - timedelta(days=months * 30)
        query = query.filter(FeeVoucher.generated_at >= cutoff)

    vouchers = query.order_by(FeeVoucher.due_date.desc()).all()

    student_ids = {v.student_id for v in vouchers}
    names_by_id = {
        u.id: u.full_name
        for u in db.query(User).filter(User.id.in_(student_ids or [uuid.uuid4()])).all()
    }
    # Batch-loaded latest-proof-per-voucher (one query total) instead of
    # _voucher_out's default per-voucher lookup — this endpoint is what the
    # Pending Proofs review screen polls, so on a school with hundreds of
    # vouchers this was hundreds of extra round-trips per page load.
    latest_proofs_by_voucher = _latest_proofs_by_voucher(db, [v.id for v in vouchers])
    return [
        _voucher_out(db, v, names_by_id.get(v.student_id, "Unknown"),
                     latest_proof=latest_proofs_by_voucher.get(v.id))
        for v in vouchers
    ]


@router.post("/students/{student_id}/generate-bill", response_model=FeeVoucherOut, status_code=status.HTTP_201_CREATED)
def generate_fee_bill(student_id: uuid.UUID, db: Session = Depends(get_db),
                       current_user: User = Depends(require_roles("admin", "coordinator"))):
    """
    On-demand "Generate Fee Bill" action (Admin/Coordinator Fee Structures
    view) — distinct from the scheduled generate_fee_vouchers() job in
    core/jobs.py, which stamps every student with the same flat
    settings.FEE_VOUCHER_DEFAULT_AMOUNT. This endpoint instead prices the
    bill from each of the student's active enrollments' fee_structures row
    (a per-student override if one is set, else the subject-wide default),
    which is the whole point of the Fee Structures feature — falling back
    to the flat default here would silently bypass it.

    Same "one voucher per student per batch" rule as the scheduled job:
    if a non-deleted voucher already exists for this student in the
    current batch, this returns 409 rather than creating a second one.
    """
    student = db.query(User).filter(User.id == student_id, User.role == "student").first()
    if not student:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found")

    current_batch = db.query(Batch).filter(Batch.is_current.is_(True), Batch.deleted_at.is_(None)).first()
    if not current_batch:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No current batch is set — mark a batch as current before generating fee bills.",
        )

    existing = db.query(FeeVoucher).filter(
        FeeVoucher.student_id == student_id,
        FeeVoucher.batch_id == current_batch.id,
        FeeVoucher.deleted_at.is_(None),
    ).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"{student.full_name} already has a fee bill for {current_batch.name} ({_voucher_number(existing)}).",
        )

    enrollments = db.query(Enrollment).filter(
        Enrollment.student_id == student_id,
        Enrollment.batch_id == current_batch.id,
        Enrollment.status == "active",
        Enrollment.deleted_at.is_(None),
    ).all()
    if not enrollments:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"{student.full_name} has no active subject enrollment in {current_batch.name} — nothing to bill.",
        )

    total = Decimal("0")
    missing_subject_names: list[str] = []
    for enrollment in enrollments:
        fs = (
            db.query(FeeStructure).filter(
                FeeStructure.subject_id == enrollment.subject_id,
                FeeStructure.student_id == student_id,
                FeeStructure.deleted_at.is_(None),
            ).first()
            or db.query(FeeStructure).filter(
                FeeStructure.subject_id == enrollment.subject_id,
                FeeStructure.student_id.is_(None),
                FeeStructure.deleted_at.is_(None),
            ).first()
        )
        if fs is None:
            subject = db.query(Subject).filter(Subject.id == enrollment.subject_id).first()
            missing_subject_names.append(subject.name if subject else str(enrollment.subject_id))
            continue
        total += fs.amount

    if missing_subject_names:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=(
                "No fee structure is set for: " + ", ".join(missing_subject_names)
                + ". Set a fee for these subjects (Fee Structures) before generating this bill."
            ),
        )

    due_date = (datetime.now(timezone.utc) + timedelta(days=settings.FEE_VOUCHER_DUE_DAYS)).date()
    voucher = FeeVoucher(student_id=student_id, batch_id=current_batch.id, amount=total, due_date=due_date)
    db.add(voucher)
    db.commit()
    db.refresh(voucher)

    log_action(
        db, current_user.id, "fee_bill_generated", "fee_vouchers", voucher.id, None,
        {
            "batch_id": str(current_batch.id),
            "amount": str(total),
            "subject_ids": [str(e.subject_id) for e in enrollments],
        },
    )
    notify(
        db, student.id, "fee_bill_generated",
        f"A new fee bill ({_voucher_number(voucher)}) of {total} has been generated. Due {due_date.isoformat()}.",
        related_entity_type="fee_vouchers", related_entity_id=voucher.id,
        email_to=student.email, email_subject="New fee bill generated",
    )
    db.commit()

    return _voucher_out(db, voucher, student.full_name)


@router.get("/vouchers/{voucher_id}/bill-pdf")
def download_fee_bill_pdf(voucher_id: uuid.UUID, db: Session = Depends(get_db),
                           current_user: User = Depends(get_current_user)):
    """
    Renders the voucher as a simple PDF on the fly — nothing is written to
    disk. Unlike fee proofs (a real uploaded file that has to persist),
    every field on this PDF already lives on the voucher/enrollment rows,
    so regenerating it per request avoids adding a new storage path and a
    new fee_vouchers column just to remember "where the PDF is."

    NEW DEPENDENCY: this needs `reportlab` (not yet in this project — the
    existing pypdf dependency only reads/recompresses PDFs, it doesn't
    draw text). Add reportlab to requirements.txt before deploying this.

    RBAC reuses _can_access_student_fees — the same student/parent/
    admin/coordinator rule as every other read in this router.
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas
    import io

    voucher = db.query(FeeVoucher).filter(FeeVoucher.id == voucher_id, FeeVoucher.deleted_at.is_(None)).first()
    if not voucher:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Voucher not found")
    if not _can_access_student_fees(current_user, voucher.student_id, db):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not permitted")

    student = db.query(User).filter(User.id == voucher.student_id).first()
    batch = db.query(Batch).filter(Batch.id == voucher.batch_id).first()
    subject_names = [
        s.name for s in (
            db.query(Subject).filter(Subject.id == e.subject_id).first()
            for e in db.query(Enrollment).filter(
                Enrollment.student_id == voucher.student_id,
                Enrollment.batch_id == voucher.batch_id,
                Enrollment.status == "active",
                Enrollment.deleted_at.is_(None),
            ).all()
        ) if s
    ]
    voucher_number = _voucher_number(voucher)
    status_text = _status_text_for(_latest_proof_for(db, voucher.id))

    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    y = height - 30 * mm

    c.setFont("Helvetica-Bold", 16)
    c.drawString(20 * mm, y, "Fee Bill / Voucher")
    y -= 12 * mm

    c.setFont("Helvetica", 11)
    for line in [
        f"Voucher No: {voucher_number}",
        f"Student: {student.full_name if student else 'Unknown'}",
        f"Batch: {batch.name if batch else 'Unknown'}",
        f"Subjects: {', '.join(subject_names) if subject_names else '-'}",
        f"Amount Payable: {voucher.amount}",
        f"Due Date: {voucher.due_date.isoformat()}",
        f"Generated: {voucher.generated_at.strftime('%Y-%m-%d %H:%M UTC')}",
        f"Status: {status_text.capitalize()}",
    ]:
        c.drawString(20 * mm, y, line)
        y -= 8 * mm

    c.showPage()
    c.save()
    pdf_bytes = buffer.getvalue()
    buffer.close()

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="{voucher_number}.pdf"'},
    )


@router.post("/proofs", response_model=FeeProofOut, status_code=status.HTTP_201_CREATED)
def upload_fee_proof(
    voucher_id: uuid.UUID = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("student", "parent")),
):
    """
    Real multipart upload — saved to local disk under FEE_PROOF_UPLOAD_DIR.
    file_url stores only the generated filename (not a URL and not an
    absolute path); reads always go through GET /proofs/{id}/file below so
    RBAC applies on every access, not just at upload time.
    """
    voucher = db.query(FeeVoucher).filter(
        FeeVoucher.id == voucher_id, FeeVoucher.deleted_at.is_(None)
    ).first()
    if not voucher:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Voucher not found")
    if not _can_access_student_fees(current_user, voucher.student_id, db):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not permitted to submit proof for this student")

    stored_name = save_fee_proof_file(file)

    proof = FeeProof(voucher_id=voucher_id, uploaded_by=current_user.id, file_url=stored_name)
    db.add(proof)
    db.commit()
    db.refresh(proof)
    return proof


@router.get("/proofs/{proof_id}/file")
def download_fee_proof_file(proof_id: uuid.UUID, db: Session = Depends(get_db),
                             current_user: User = Depends(get_current_user)):
    """
    Streams the actual proof file back. Deliberately NOT a static file
    mount — RBAC (same student/parent/admin/coordinator check as everywhere
    else in this router) is enforced per-request here instead.
    """
    proof = db.query(FeeProof).filter(FeeProof.id == proof_id, FeeProof.deleted_at.is_(None)).first()
    if not proof:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Proof not found")

    voucher = db.query(FeeVoucher).filter(FeeVoucher.id == proof.voucher_id).first()
    if not voucher or not _can_access_student_fees(current_user, voucher.student_id, db):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not permitted")

    if proof.file_url == settings.FEE_PROOF_RETENTION_PLACEHOLDER:
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail="This proof's file was purged under the 90-day retention policy.",
        )

    path = resolve_fee_proof_path(proof.file_url)
    if not path.exists():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File missing on disk")

    return FileResponse(path)


@router.get("/vouchers/{voucher_id}/proofs", response_model=List[FeeProofOut])
def list_proofs_for_voucher(voucher_id: uuid.UUID, db: Session = Depends(get_db),
                             current_user: User = Depends(get_current_user)):
    voucher = db.query(FeeVoucher).filter(FeeVoucher.id == voucher_id, FeeVoucher.deleted_at.is_(None)).first()
    if not voucher:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Voucher not found")
    if not _can_access_student_fees(current_user, voucher.student_id, db):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not permitted")
    return db.query(FeeProof).filter(
        FeeProof.voucher_id == voucher_id, FeeProof.deleted_at.is_(None)
    ).order_by(FeeProof.uploaded_at.desc()).all()


@router.patch("/proofs/{proof_id}/review", response_model=FeeProofOut)
def review_fee_proof(proof_id: uuid.UUID, payload: FeeProofReview, db: Session = Depends(get_db),
                      current_user: User = Depends(require_roles("admin", "coordinator"))):
    proof = db.query(FeeProof).filter(FeeProof.id == proof_id, FeeProof.deleted_at.is_(None)).first()
    if not proof:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Proof not found")
    if payload.status not in ("approved", "rejected"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="status must be approved or rejected")

    proof.status = payload.status
    proof.reviewed_by = current_user.id
    proof.reviewed_at = datetime.now(timezone.utc)
    proof.rejection_reason = payload.rejection_reason

    log_action(db, current_user.id, "fee_proof_reviewed", "fee_proofs", proof.id, None, {"status": payload.status})

    voucher = db.query(FeeVoucher).filter(FeeVoucher.id == proof.voucher_id).first()
    student = db.query(User).filter(User.id == voucher.student_id).first() if voucher else None
    if student:
        if payload.status == "approved":
            message = "Your fee payment proof was approved."
        else:
            reason = f" Reason: {payload.rejection_reason}" if payload.rejection_reason else ""
            message = f"Your fee payment proof was rejected.{reason} You can upload a new one."
        notify(
            db, student.id, "fee_proof_reviewed", message,
            related_entity_type="fee_proofs", related_entity_id=proof.id,
            email_to=student.email, email_subject="Fee proof " + payload.status,
        )

    db.commit()
    db.refresh(proof)
    return proof


# ---------------------------------------------------------------------------
# Fee Structures — Admin Sub-Sprint 4: "set subject/student fee bills using
# preset layouts." The table (fee_structures) existed since an early schema
# migration but had zero backend before this — voucher creation had no
# reusable default to pull from.
# ---------------------------------------------------------------------------
def _fee_structure_out(db: Session, fs: FeeStructure) -> FeeStructureOut:
    """Single-row version — used by create/update, which only ever have
    the one row they just wrote/changed, so there's nothing to batch."""
    subject = db.query(Subject).filter(Subject.id == fs.subject_id).first()
    student = db.query(User).filter(User.id == fs.student_id).first() if fs.student_id else None
    return FeeStructureOut(
        id=fs.id, subject_id=fs.subject_id, subject_name=subject.name if subject else None,
        student_id=fs.student_id, student_name=student.full_name if student else None,
        amount=fs.amount, set_by=fs.set_by, created_at=fs.created_at,
    )


def _fee_structures_out_batch(db: Session, rows: List[FeeStructure]) -> List[FeeStructureOut]:
    """List version — GET /structures was issuing 2 extra queries per row
    (Subject lookup + optional User lookup), so a school with e.g. 40
    subject defaults + overrides meant ~80 extra round-trips on every
    Fee Structures page load. Batches both lookups into 2 queries total,
    regardless of how many rows are returned."""
    if not rows:
        return []
    subject_ids = {r.subject_id for r in rows}
    student_ids = {r.student_id for r in rows if r.student_id}

    subjects_by_id = {
        s.id: s.name for s in db.query(Subject).filter(Subject.id.in_(subject_ids)).all()
    } if subject_ids else {}
    students_by_id = {
        u.id: u.full_name for u in db.query(User).filter(User.id.in_(student_ids)).all()
    } if student_ids else {}

    return [
        FeeStructureOut(
            id=r.id, subject_id=r.subject_id, subject_name=subjects_by_id.get(r.subject_id),
            student_id=r.student_id, student_name=students_by_id.get(r.student_id) if r.student_id else None,
            amount=r.amount, set_by=r.set_by, created_at=r.created_at,
        )
        for r in rows
    ]


@router.get("/structures", response_model=List[FeeStructureOut])
def list_fee_structures(subject_id: Optional[uuid.UUID] = None, db: Session = Depends(get_db),
                         current_user: User = Depends(require_roles("admin", "coordinator"))):
    query = db.query(FeeStructure).filter(FeeStructure.deleted_at.is_(None))
    if subject_id:
        query = query.filter(FeeStructure.subject_id == subject_id)
    rows = query.order_by(FeeStructure.created_at.desc()).all()
    return _fee_structures_out_batch(db, rows)


@router.post("/structures", response_model=FeeStructureOut, status_code=status.HTTP_201_CREATED)
def create_fee_structure(payload: FeeStructureCreate, db: Session = Depends(get_db),
                          current_user: User = Depends(require_roles("admin", "coordinator"))):
    """
    The two partial unique indexes on fee_structures (subject-wide default,
    and per-student override) enforce "only one active row" at the DB
    level — a second POST for the same subject (+ same student_id, or both
    NULL) raises IntegrityError, which we translate to a clear 409 instead
    of a raw DB error leaking through. To change an existing amount, use
    PATCH, not a second POST.
    """
    fs = FeeStructure(**payload.model_dump(), set_by=current_user.id)
    db.add(fs)
    try:
        db.commit()
    except Exception:
        db.rollback()
        scope = "this student" if payload.student_id else "the whole subject"
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"A fee is already set for {scope} on this subject — edit that one instead of creating a new one.",
        )
    db.refresh(fs)
    log_action(db, current_user.id, "fee_structure_created", "fee_structures", fs.id, None,
               {"subject_id": str(payload.subject_id), "student_id": str(payload.student_id) if payload.student_id else None, "amount": str(payload.amount)})
    db.commit()
    return _fee_structure_out(db, fs)


@router.patch("/structures/{structure_id}", response_model=FeeStructureOut)
def update_fee_structure(structure_id: uuid.UUID, payload: FeeStructureAmountUpdate, db: Session = Depends(get_db),
                          current_user: User = Depends(require_roles("admin", "coordinator"))):
    fs = db.query(FeeStructure).filter(FeeStructure.id == structure_id, FeeStructure.deleted_at.is_(None)).first()
    if not fs:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Fee structure not found")
    old_amount = fs.amount
    fs.amount = payload.amount
    log_action(db, current_user.id, "fee_structure_updated", "fee_structures", fs.id,
               {"amount": str(old_amount)}, {"amount": str(payload.amount)})
    db.commit()
    db.refresh(fs)
    return _fee_structure_out(db, fs)


@router.delete("/structures/{structure_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_fee_structure(structure_id: uuid.UUID, db: Session = Depends(get_db),
                          current_user: User = Depends(require_roles("admin", "coordinator"))):
    fs = db.query(FeeStructure).filter(FeeStructure.id == structure_id, FeeStructure.deleted_at.is_(None)).first()
    if not fs:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Fee structure not found")
    fs.deleted_at = datetime.now(timezone.utc)
    db.commit()
